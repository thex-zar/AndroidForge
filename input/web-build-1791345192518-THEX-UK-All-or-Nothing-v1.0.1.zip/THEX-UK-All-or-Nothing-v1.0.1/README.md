# THEX UK All or Nothing Lucky Generator v1.0.1

AndroidForge-ready Android project.

App name: THEX
Package: com.thex.allornothing
Version: 1.0.1
Minimum Android: 6.0 (API 23)
Target SDK: 34

Generates 12 unique random numbers from 1 to 24.
This is not a prediction system and does not guarantee lottery results.
