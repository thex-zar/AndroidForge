package com.thex.allornothing;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private final Random random = new Random();
    private TextView result;

    private TextView label(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(0xFF111111);
        v.setPadding(10, 10, 10, 10); return v;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(22,22,22,22);

        TextView title = label("THEX", 32); title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); box.addView(title);
        TextView sub = label("UK All or Nothing Lucky Generator\nVersion 1.0.1", 17);
        sub.setGravity(Gravity.CENTER); box.addView(sub);

        Button generate = new Button(this); generate.setText("GENERATE 12 LUCKY NUMBERS"); box.addView(generate);
        Button clear = new Button(this); clear.setText("CLEAR"); box.addView(clear);

        result = label("Your numbers will appear here.", 22); result.setGravity(Gravity.CENTER); box.addView(result);
        TextView note = label("\nNumbers are randomly generated from 1–24.\n\nFor entertainment only. This app cannot predict lottery results or guarantee winnings.\n\nTHEX • UK All or Nothing", 14);
        note.setGravity(Gravity.CENTER); box.addView(note);

        generate.setOnClickListener(v -> generate());
        clear.setOnClickListener(v -> result.setText("Your numbers will appear here."));
        setContentView(box);
    }

    private void generate() {
        ArrayList<Integer> pool = new ArrayList<>();
        for (int i=1;i<=24;i++) pool.add(i);
        Collections.shuffle(pool, random);
        int[] a = new int[12];
        for (int i=0;i<12;i++) a[i]=pool.get(i);
        Arrays.sort(a);
        StringBuilder s=new StringBuilder("YOUR THEX NUMBERS\n\n");
        for(int i=0;i<a.length;i++){ if(i>0)s.append("   "); s.append(String.format(Locale.US,"%02d",a[i])); if((i+1)%4==0)s.append("\n"); }
        s.append("\nGenerated randomly."); result.setText(s.toString());
    }
}
