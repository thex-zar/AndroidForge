# UK All or Nothing Lucky Number Generator

Android 10+ project for a phone-friendly lucky-number generator.

## Game format
- 12 numbers selected from 1–24.
- The game is operated by the Health Lottery.
- Jackpot condition: match all 12 or match none.
- This app does not predict future winning numbers.

## Included
- Random 12-number generator
- Five-line generator
- Selection profile
- Latest-results web feed
- Offline generator fallback
- Android 10 minimum
- No NumPy / no Pandas / Java-only Android app

## Build
Open the project in an Android Gradle-compatible IDE/builder and build:
`:app:assembleDebug`

The generated APK will be:
`app/build/outputs/apk/debug/app-debug.apk`

## Feed note
The current feed uses an independent public results page for informational display.
It is deliberately not presented as an official prize-validation service.


## v1.0.1 cloud-build compatibility
Conservative Android Gradle Plugin/dependency versions, Java 8 compile options, and reduced cloud-build complexity.
