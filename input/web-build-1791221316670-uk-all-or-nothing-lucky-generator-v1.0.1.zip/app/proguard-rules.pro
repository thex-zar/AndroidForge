# Keep default rules for this simple application.
