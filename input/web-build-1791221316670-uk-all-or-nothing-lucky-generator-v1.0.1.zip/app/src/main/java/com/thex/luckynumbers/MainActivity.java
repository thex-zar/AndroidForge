package com.thex.luckynumbers;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private TextView numbersView, statsView, feedView;
    private final Random random = new Random();
    private final Handler handler = new Handler();

    // Public information page used as an independent results source.
    // The app does NOT claim this is an official prize-validation feed.
    private static final String FEED_URL =
            "https://lotteryuk.net/all-or-nothing";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numbersView = findViewById(R.id.numbers);
        statsView = findViewById(R.id.stats);
        feedView = findViewById(R.id.feed);

        Button generate = findViewById(R.id.generateButton);
        Button multi = findViewById(R.id.multiButton);
        Button refresh = findViewById(R.id.refreshButton);

        generate.setOnClickListener(v -> showLine(generateLine()));
        multi.setOnClickListener(v -> generateFive());
        refresh.setOnClickListener(v -> fetchFeed());

        showLine(generateLine());
        fetchFeed();
    }

    private List<Integer> generateLine() {
        List<Integer> pool = new ArrayList<>();
        for (int i = 1; i <= 24; i++) pool.add(i);
        Collections.shuffle(pool, random);
        List<Integer> result = new ArrayList<>(pool.subList(0, 12));
        Collections.sort(result);
        return result;
    }

    private void showLine(List<Integer> line) {
        numbersView.setText(format(line));
        statsView.setText(buildSelectionStats(line));
    }

    private String format(List<Integer> line) {
        StringBuilder b = new StringBuilder();
        for (int n : line) {
            if (b.length() > 0) b.append("  ");
            b.append(String.format("%02d", n));
        }
        return b.toString();
    }

    private String buildSelectionStats(List<Integer> line) {
        int low = 0, high = 0, odd = 0, even = 0;
        for (int n : line) {
            if (n <= 12) low++; else high++;
            if (n % 2 == 0) even++; else odd++;
        }
        return "Selection profile\n"
                + "Low (01–12): " + low + "\n"
                + "High (13–24): " + high + "\n"
                + "Odd: " + odd + "    Even: " + even + "\n\n"
                + "This profile describes the generated line only; it does not increase "
                + "the mathematical chance of a future combination.";
    }

    private void generateFive() {
        StringBuilder b = new StringBuilder();
        for (int i = 1; i <= 5; i++) {
            b.append("Line ").append(i).append(": ")
                    .append(format(generateLine())).append("\n\n");
        }
        numbersView.setText(b.toString().trim());
        statsView.setText("Five independent random lines generated.");
    }

    private void fetchFeed() {
        feedView.setText("Checking latest results…");
        new Thread(() -> {
            String result;
            try {
                result = download(FEED_URL);
            } catch (Exception e) {
                result = "Feed unavailable right now.\n"
                        + "You can still use the generator offline.\n\n"
                        + "Source: " + FEED_URL;
            }
            final String out = parseLatest(result);
            runOnUiThread(() -> feedView.setText(out));
        }).start();
    }

    private String download(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0");
        c.setRequestMethod("GET");

        BufferedReader r = new BufferedReader(
                new InputStreamReader(c.getInputStream()));
        StringBuilder b = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) b.append(line).append("\n");
        r.close();
        c.disconnect();
        return b.toString();
    }

    private String parseLatest(String html) {
        // Tries common number-list patterns. If the source changes its HTML,
        // the app safely reports that parsing needs updating.
        Pattern p = Pattern.compile(
                "\\b([1-9]|1[0-9]|2[0-4])\\b(?:\\s+|</[^>]+>\\s*)"
        );
        Matcher m = p.matcher(html);

        List<Integer> found = new ArrayList<>();
        while (m.find() && found.size() < 12) {
            int n;
            try { n = Integer.parseInt(m.group(1)); }
            catch (Exception e) { continue; }
            if (!found.contains(n)) found.add(n);
        }

        if (found.size() == 12) {
            Collections.sort(found);
            return "Latest available feed numbers:\n\n"
                    + format(found)
                    + "\n\nSource: independent results page\n"
                    + "Always verify against the operator before relying on a result.";
        }

        return "Latest feed could not be parsed automatically.\n"
                + "The generator remains available.\n\n"
                + "Source: independent results page";
    }
}
